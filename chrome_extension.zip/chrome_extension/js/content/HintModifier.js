console.log("ruhinginagign")

$(function() {
	$("#preview").css({"width": "20%", left: "80%"});
	$("#editor").css({"width": "80%"});
})