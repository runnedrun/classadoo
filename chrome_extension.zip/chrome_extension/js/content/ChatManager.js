ChatManager = function(dataManager) {
	var m = dataManager

	function updateChatWindow() {

	}

	function createChatWindow() {
		$("<html><body><div id='chat-wrapper'></div></body></html")
	}

	respond("chatHistory")
}