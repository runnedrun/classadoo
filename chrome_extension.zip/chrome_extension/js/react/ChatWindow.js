var React = require('react');
require("../content/Util.js");
require("../../third_party/firebase.min.js");

$(function() {
	var id = location.hash.slice(1,location.hash.length);	
	console.log("chrome", chrome.runtime);
	// var manager = new ChatManager(Firebase())
	// ReactDOM.render(<ChatWindow />)   
})

// ChatManager = function(parentRef, studentId) {
// 	var self = this;
// 	var messages = []

// 	var ref = parentRef.child(studentId).child("state/chatHistory");

// 	ref.on("child_added", function(childSnapshot) {
// 		messages.push(childSnapshot.val());
// 	})	

// 	self.push = function(message) {		
// 		ref.push(message)	
// 	}

// 	self.read = function() {
// 		return messages
// 	} 
// }

ChatWindow = React.createClass({  	
	componentDidUpdate: function() {		
		var history = $(this.history)
		history.scrollTop(history[0].scrollHeight);
	},

	componentDidMount: function() {		
		var history = $(this.history)
		history.scrollTop(history[0].scrollHeight);
	},

	sendMessage: function(event) {
		var enterKeyCode = 13;  		

		if (event.keyCode === enterKeyCode && !event.shiftKey) {						
			var target = $(event.target);			
			var value =  $(target).val();	

			if (value != "") {                        	
				this.studentUpdater.push("chatHistory", {text: value, isStudent: false, timestamp: Firebase.ServerValue.TIMESTAMP});
			}           
			
			event.preventDefault();
			target.val("");
		}     
	},

	render: function() {		
		var chatHistory = this.props.state.global.chatHistory || {}
		this.studentUpdater = this.props.classState.studentUpdater(this.props.state.id);


		var messages = Util.objectValues(chatHistory).sort(function(a, b) {
			return a.timestamp - b.timestamp
		})		

		return ( 
			<div className="row chat-window">				
				<div className="history-window" ref={(ref) => this.history = ref}>
					{messages.map(function(message) {
						if (message.isStudent) {
							return <div className="theirs">{message.text}</div>
						} else {
							return <div className="yours">{message.text}</div>
						}
					})}
				</div>
				<div className="input-window">
					<textarea onKeyDown={this.sendMessage} className="input-area"> 
					</textarea>
				</div>				
			</div>
		)
	}
})