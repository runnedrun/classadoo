ScreenshotManager = function(dataManager) {
	var m = dataManager;
	var stream = false;

	function capture() {
		var deferred  = new $.Deferred();
		chrome.tabs.captureVisibleTab(null, {}, function (image) {   			
   			deferred.resolve(image);
		});	

		return deferred.promise();
	}	

	function screenshot() {
		capture().then(function(dataUrl) {
			m.globalSet({screenshot: {img: dataUrl, timestamp: Firebase.ServerValue.TIMESTAMP }});
		})					
	}

	function startStream(speed) {
		stream = true;

		function streamCapture() {
			if (stream) {
				screenshot()
				setTimeout(streamCapture, speed);
			}						
		}

		streamCapture();
	}

	m.listenOnGlobalProp("doScreenshot", function(shouldCapture) {
		if (shouldCapture) {
			screenshot()
		} 		
	})

	m.listenOnGlobalProp("doScreenshare", function(doScreenshare) {
		var speed = Number(doScreenshare);
		console.log(doScreenshare)
		if (speed) {
			startStream(speed)
		} else {
			stream = false;
		}
	})
}