console.log("popo up load")

PopupMessageManager = function(dataManager) {
	console.log("popo up init")
	var m = dataManager

	var popupHeight = 200;
	var popupWidth = 400;
	var existingWindow; 

	m.listenOnGlobalProp("popupMessage", function(message) {
		console.log("popo up receive")
		if (message) {
			// remove the timestamp we use to ensure uniqueness
			var displayMessage = message.split("%%")[0];
			 chrome.system.display.getInfo(function(infos) {
			 	// arbitarily select the first one
			 	var info = infos[0];

			 	var width = info.workArea.width;
			 	var height = info.workArea.height;
			 	var top = Math.floor(height / 2 - popupHeight / 2);
			 	var left = Math.floor(width / 2 - popupWidth / 2);

			 	existingWindow = chrome.windows.create({ url: "/html/message-popup.html#" + displayMessage, left: left, top: top, width: popupWidth, height: popupHeight })
			 })			
		}
	})	
}