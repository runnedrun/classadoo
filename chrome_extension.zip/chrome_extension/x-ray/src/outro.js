// Make sure we don't conflict in any way with our parent window.
jQuery.noConflict(true);
})(window);
